
const express = require('express');
const { 
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  AlignmentType, BorderStyle, WidthType, ShadingType, VerticalAlign,
  Header, PageBreak, ImageRun
} = require('docx');
const fs = require('fs');
const path = require('path');
const app = express();

app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// ── Color constants ────────────────────────────────────────────────────────
const BLUE       = "1B3A6B";
const LIGHT_BLUE = "E8EEF7";
const MID_BLUE   = "B5D4F4";
const DARK_GRAY  = "444444";
const MED_GRAY   = "666666";
const LIGHT_GRAY = "F5F5F5";
const ALT_ROW    = "FAFBFD";
const WHITE      = "FFFFFF";
const BLACK      = "000000";

const noBorder   = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
const noBorders  = { top: noBorder, bottom: noBorder, left: noBorder, right: noBorder };
const thinBorder = { style: BorderStyle.SINGLE, size: 4, color: "CCCCCC" };
const thinBorders= { top: thinBorder, bottom: thinBorder, left: thinBorder, right: thinBorder };

function cell(children, opts = {}) {
  return new TableCell({
    children,
    borders:       opts.borders  || noBorders,
    shading:       opts.shading  || { fill: WHITE, type: ShadingType.CLEAR },
    margins:       opts.margins  || { top: 80, bottom: 80, left: 120, right: 120 },
    width:         opts.width    ? { size: opts.width, type: WidthType.DXA } : undefined,
    verticalAlign: opts.vAlign   || VerticalAlign.TOP,
    columnSpan:    opts.span,
  });
}

function para(text, opts = {}) {
  return new Paragraph({
    alignment: opts.align || AlignmentType.LEFT,
    spacing:   { before: opts.before || 0, after: opts.after || 0, line: opts.line },
    children:  [new TextRun({
      text, bold: opts.bold || false, color: opts.color || BLACK,
      size: opts.size || 22, font: "Arial", italics: opts.italic || false,
    })],
    border: opts.border,
  });
}

function multiRun(runs, opts = {}) {
  return new Paragraph({
    alignment: opts.align || AlignmentType.LEFT,
    spacing:   { before: opts.before || 0, after: opts.after || 0 },
    children:  runs.map(r => new TextRun({ font: "Arial", ...r })),
    border:    opts.border,
  });
}

function labelValue(label, value) {
  return new Paragraph({
    spacing: { before: 0, after: 60 },
    children: [
      new TextRun({ text: label,        color: MED_GRAY, size: 20, font: "Arial" }),
      new TextRun({ text: "  " + value, color: BLACK,    size: 20, font: "Arial", bold: true }),
    ]
  });
}

function sectionLabel(text) {
  return new Paragraph({
    spacing: { before: 240, after: 100 },
    border:  { bottom: { style: BorderStyle.SINGLE, size: 4, color: BLUE, space: 4 } },
    children: [new TextRun({
      text: text.toUpperCase(), bold: true, color: BLUE,
      size: 18, font: "Arial", characterSpacing: 40,
    })]
  });
}

function tcHeading(text) {
  return new Paragraph({
    spacing: { before: 200, after: 80 },
    children: [new TextRun({ text, bold: true, color: BLUE, size: 21, font: "Arial" })]
  });
}

function tcBody(text) {
  return new Paragraph({
    spacing: { before: 0, after: 120 },
    children: [new TextRun({ text, color: DARK_GRAY, size: 19, font: "Arial" })],
    alignment: AlignmentType.JUSTIFIED,
  });
}

function serviceRow(title, desc) {
  return new TableRow({ children: [
    cell([new Paragraph({ spacing: { before: 0, after: 0 },
      children: [new TextRun({ text: "\u2713", color: BLUE, size: 24, bold: true, font: "Arial" })]
    })], { width: 500, borders: noBorders, margins: { top: 80, bottom: 80, left: 80, right: 80 } }),
    cell([
      para(title, { bold: true, size: 22, color: DARK_GRAY, after: 40 }),
      para(desc,  { size: 20, color: MED_GRAY }),
    ], { width: 9580, borders: noBorders }),
  ]});
}

function spacerRow() {
  return new TableRow({ children: [
    cell([para("", { size: 14 })], { width: 500,  borders: noBorders }),
    cell([para("", { size: 14 })], { width: 9580, borders: noBorders }),
  ]});
}

function benefitRow(items) {
  const colW = Math.floor(10080 / items.length);
  return new TableRow({ children: items.map(item =>
    cell([new Paragraph({ spacing: { before: 0, after: 0 }, children: [
      new TextRun({ text: "\u2713  ", color: BLUE,      size: 20, bold: true, font: "Arial" }),
      new TextRun({ text: item,       color: DARK_GRAY,  size: 20,             font: "Arial" }),
    ]})], {
      width: colW, borders: noBorders,
      shading: { fill: LIGHT_GRAY, type: ShadingType.CLEAR },
      margins: { top: 100, bottom: 100, left: 160, right: 160 }
    })
  )});
}

function sigLine(label) {
  return [
    new Paragraph({
      spacing: { before: 360, after: 60 },
      border:  { bottom: { style: BorderStyle.SINGLE, size: 4, color: "999999" } },
      children: [new TextRun({ text: " ", font: "Arial", size: 22 })]
    }),
    para(label, { size: 18, color: MED_GRAY, before: 40 }),
  ];
}

function eqScopeBlock(name, qty, visits, cats) {
  const catNames  = Object.keys(cats);
  const numCats   = catNames.length;
  const colW      = Math.floor(10080 / numCats);
  const colWidths = catNames.map((_, i) =>
    i < numCats - 1 ? colW : 10080 - colW * (numCats - 1)
  );

  const headerRow = new TableRow({ children: [
    new TableCell({
      columnSpan: numCats,
      children: [new Paragraph({ spacing: { before: 0, after: 0 }, children: [
        new TextRun({ text: name, bold: true, color: WHITE, size: 26, font: "Arial" }),
        new TextRun({ text: `   \u00B7   ${qty} unit${qty > 1 ? 's' : ''} on site  \u00B7  ${visits} visit${visits > 1 ? 's' : ''} per year`,
          color: "AABCDD", size: 20, font: "Arial" }),
      ]})],
      borders: noBorders,
      shading: { fill: BLUE, type: ShadingType.CLEAR },
      margins: { top: 160, bottom: 160, left: 220, right: 220 },
      width:   { size: 10080, type: WidthType.DXA },
    })
  ]});

  const catLabelRow = new TableRow({ children: catNames.map((cat, i) =>
    cell([para(cat, { bold: true, size: 19, color: BLUE })], {
      width: colWidths[i],
      borders: {
        top: noBorder,
        bottom: { style: BorderStyle.SINGLE, size: 8, color: MID_BLUE },
        left:   i === 0 ? noBorder : { style: BorderStyle.SINGLE, size: 4, color: MID_BLUE },
        right:  noBorder,
      },
      shading:  { fill: LIGHT_BLUE, type: ShadingType.CLEAR },
      margins:  { top: 100, bottom: 100, left: 160, right: 120 },
    })
  )});

  const maxItems = Math.max(...catNames.map(c => cats[c].length));
  const itemRows = [];
  for (let i = 0; i < maxItems; i++) {
    const isLast = i === maxItems - 1;
    itemRows.push(new TableRow({ children: catNames.map((cat, ci) => {
      const item = cats[cat][i];
      return cell(
        item ? [new Paragraph({ spacing: { before: 0, after: 0 }, children: [
          new TextRun({ text: "\u00B7  ", color: BLUE, size: 20, bold: true, font: "Arial" }),
          new TextRun({ text: item, color: DARK_GRAY, size: 19, font: "Arial" }),
        ]})] : [para("", { size: 19 })],
        {
          width: colWidths[ci],
          borders: {
            top:    noBorder,
            bottom: isLast ? noBorder : { style: BorderStyle.SINGLE, size: 2, color: "EEF3FA" },
            left:   ci === 0 ? noBorder : { style: BorderStyle.SINGLE, size: 4, color: "EEF3FA" },
            right:  noBorder,
          },
          shading:  { fill: i % 2 === 0 ? WHITE : ALT_ROW, type: ShadingType.CLEAR },
          margins:  { top: 90, bottom: 90, left: 160, right: 120 },
        }
      );
    })}));
  }

  const totalPoints = catNames.reduce((s, c) => s + cats[c].length, 0);
  const footerRow = new TableRow({ children: [
    new TableCell({
      columnSpan: numCats,
      children: [new Paragraph({ spacing: { before: 0, after: 0 }, children: [
        new TextRun({ text: `${totalPoints}+ inspection points per visit`, color: MED_GRAY, size: 18, font: "Arial" }),
      ]})],
      borders: { top: { style: BorderStyle.SINGLE, size: 4, color: "DDDDDD" }, bottom: noBorder, left: noBorder, right: noBorder },
      shading:  { fill: LIGHT_GRAY, type: ShadingType.CLEAR },
      margins:  { top: 80, bottom: 80, left: 220, right: 220 },
      width:    { size: 10080, type: WidthType.DXA },
    })
  ]});

  return [
    new Table({ width: { size: 10080, type: WidthType.DXA }, columnWidths: colWidths,
      rows: [headerRow, catLabelRow, ...itemRows, footerRow] }),
    new Paragraph({ spacing: { before: 0, after: 220 }, children: [] }),
  ];
}

// ── Equipment catalog ──────────────────────────────────────────────────────
const EQ_CATALOG = {
  rtu: {
    name: "Rooftop Unit (RTU)",
    cats: {
      'Electrical':    ['Volts/amps — compressor, condenser & evap fan motors','Tighten all electrical connections','Starters & contactors for wear','All operating and safety controls'],
      'Refrigeration': ['Refrigerant pressures','Check for refrigerant / oil leaks','Clean condenser coil','Check evaporator coil','Inspect condensate drain pan & lines'],
      'Mechanical':    ['Filters — inspect / replace per contract','Belts — inspect / replace per contract','Sheaves — wear & alignment','Blower wheels — clean','Lubricate motor & blower bearings'],
      'Heating':       ['Heat exchanger — cracks / corrosion','Burner assembly & ignition sequence','Inducer fan wheel if applicable','Overall condition of unit'],
    }
  },
  split: {
    name: "Split System (DX)",
    cats: {
      'Electrical':    ['Volts/amps — compressor & fan motors','Tighten all electrical connections','Starters & contactors for wear','Operating and safety controls'],
      'Refrigeration': ['Refrigerant pressures','Check for refrigerant / oil leaks','Condenser coil — clean per contract','Inspect condensate drain pan & lines'],
      'Mechanical':    ['Filters — inspect / replace per contract','Belts — inspect / replace per contract','Blower wheels — clean surface','Lubricate motor & blower bearings'],
      'Heating':       ['Heat exchanger — cracks / corrosion','Burner assembly if applicable','Ignition & burner sequence','Overall condition of unit'],
    }
  },
  mini: {
    name: "Ductless Mini Split",
    cats: {
      'Air & Filtration':     ['Filters — clean or replace per contract','Fan blades & housing — fouling check','Damper — adjust / lubricate if applicable','Check for moisture carryover from drain pan'],
      'Refrigeration':        ['Refrigerant pressures & levels','Check for visible refrigerant / oil leaks','Evaporator coils — clean per contract','Condenser coils — clean per contract'],
      'Electrical & Controls':['All electrical connections','Control system devices','Control box — dirt & debris','Field serviceable bearings — lubricate'],
      'Drainage':             ['P-trap drain — clean as needed','Drain pan, line & coil — check for biological growth','Condensate pump if applicable','General condition of unit'],
    }
  },
  vrf: {
    name: "VRF / VRV System",
    cats: {
      'Electrical':  ['Volts/amps — all motors','Tighten all electrical connections','All safety controls & safeties','Communication wiring integrity'],
      'Refrigeration':['Refrigerant pressures — all circuits','Check for leaks — all connections','Condenser coil — clean per contract','Oil levels if applicable'],
      'Controls':    ['Zone controller operation','Setpoints & schedules verified','Fault code review','Overall controls condition'],
      'Mechanical':  ['Fan blades & housing','Filters — indoor units per contract','Lubricate all serviceable bearings','Overall condition — all heads & ODU'],
    }
  },
  vav: {
    name: "VAV Box",
    cats: {
      'Controls':   ['Actuator operation & calibration','Thermostat / zone sensor accuracy','Setpoints & schedules verified','Occupied / unoccupied schedules'],
      'Mechanical': ['Damper blade condition & seating','Linkage — tighten & lubricate','Box casing & insulation integrity','Flow measurement if applicable'],
      'Heating':    ['Hot water coil operation if applicable','Control valve — stroke & seating','Reheat sequence of operation','Overall condition of box'],
      'Electrical': ['All electrical connections','Control board & wiring','24V transformer output','Overall condition'],
    }
  },
  reznor: {
    name: "Reznor / Unit Heater",
    cats: {
      'Combustion':     ['Burner assembly & orifices','Ignition sequence of operation','Burner sequence of operation','Gas valve operation & pressure'],
      'Heat Exchanger': ['Cracks, corrosion & deterioration','Flue & venting — blockage & condition','Combustion air — adequate supply','CO test if applicable'],
      'Electrical':     ['All electrical connections','Safety controls & limits','Thermostat calibration','Blower motor amps if applicable'],
      'General':        ['Fan blade & housing condition','Filters if applicable','Overall unit condition','Recommend service if needed'],
    }
  },
  mau: {
    name: "Make-Up Air Unit (MAU)",
    cats: {
      'Air':              ['Filters — inspect / replace per contract','Fan wheel — clean & balance check','Belts — inspect / replace per contract','Sheaves — wear & alignment'],
      'Heating / Cooling':['Heat exchanger if applicable','Gas valve & burner sequence','Cooling coil & refrigerant check','Economizer operation'],
      'Electrical':       ['All electrical connections','Contactors & starters for wear','Safety controls & limits','Overall electrical condition'],
      'General':          ['Louvers & dampers — operation','Drain pan & condensate line','Lubricate all serviceable bearings','Overall condition of unit'],
    }
  },
  erv: {
    name: "ERV / HRV",
    cats: {
      'Core & Filters':['Heat / energy recovery core — inspect & clean','Filters — clean or replace per contract','Core bypass damper operation','Defrost cycle operation if applicable'],
      'Mechanical':    ['Fan wheels — clean & condition','Belts if applicable','Lubricate all serviceable bearings','Condensate drain if applicable'],
      'Controls':      ['Controls & setpoints verified','Enthalpy sensors if applicable','Occupied / unoccupied schedules','Airflow verification'],
      'General':       ['All electrical connections','Housing integrity & seals','Overall condition of unit','Recommend service if needed'],
    }
  },
};

// ── Services list ─────────────────────────────────────────────────────────
const SERVICES = [
  ["Filter Inspection & Replacement",            "All return air filters inspected and replaced as needed. Correct filter size and MERV rating confirmed per unit specifications."],
  ["Electrical & Safety Inspection",             "All electrical connections inspected and tightened. Contactors, capacitors, fuses, and disconnects checked for wear or failure risk."],
  ["Refrigerant Level & System Pressure Check",  "Operating pressures measured and logged against manufacturer specs. Low refrigerant or leak indicators flagged and documented."],
  ["Condensate Drain Line Inspection & Cleaning","Drain pans and lines inspected and flushed. Checked for biological growth, blockages, and proper drainage to prevent overflow and water damage."],
  ["Thermostat Calibration & Controls Verification","Thermostat accuracy and staging verified. Schedules and setpoints confirmed per facility needs."],
  ["Blower Motor & Belt Inspection",             "Belt condition, tension, and alignment inspected. Blower wheel cleaned. Motor and blower bearings lubricated."],
  ["Condenser Coil Cleaning",                    "Outdoor condenser coils cleaned using low-pressure rinse and coil-safe detergent to maintain airflow and heat transfer efficiency."],
  ["Digital Service Report",                     "Digital report provided after every visit documenting all findings, readings, and recommended repairs. Kept on file for your records."],
];

// ── T&C text ──────────────────────────────────────────────────────────────
const TC_SECTIONS = [
  { heading: "Acceptance", body: "These terms and conditions are an integral part of American Air LLC's offer and form the basis of any agreement (the \"Agreement\") resulting from American Air LLC's proposal (the \"Proposal\") for the services (the \"Services\") and equipment (the \"Equipment List\") listed in the Proposal. This Agreement is subject to periodic change or amendment. The Agreement is accepted in writing by the party to whom this offer is made or an authorized agent (\"Client\") delivered to Client within 30 days from the date of the Proposal. If Client accepts the Proposal by placing an order, without the addition of any other terms and conditions of sale or any other modification, Client's order shall be deemed acceptance of the Proposal subject to American Air LLC's terms and conditions. If Client's order is expressly conditioned upon American Air LLC's acceptance or assent to terms and/or conditions other than those expressed herein, return of such Client's terms and as American Air LLC's counter-offer to perform in accordance with the Proposal and American Air LLC's terms and conditions. If Client does not reject or object in writing to American Air LLC within 10 days, the American Air LLC's counter-offer will be deemed accepted. Client's acceptance of performance by American Air LLC will in any event constitute an acceptance by Client of American Air LLC's terms and conditions. This Agreement is a subject to credit approval by American Air LLC. Upon disapproval of credit, American Air LLC may delay or suspend performance or, at its option, renegotiate prices and/or terms and conditions with Client. If American Air LLC and Client are unable to agree on such revisions, this Agreement shall be cancelled without any liability, other than Client's obligations to pay for Services and Additional Work provided by American Air LLC, to the date of cancellation." },
  { heading: "Payment Terms", body: "Client understands and agrees between the parties that payment of the net is due upon receipt of the invoice; that after thirty (30) days a service charge of 1-1/2% of the balance due shall be added for every month the balance remains unpaid; that after ninety (90) days all costs of collection, including attorney fees, shall be payable and shall be recovered in addition to sums then due. This applies to amounts due pursuant to the written contract and any extra work ordered during the course of the contract whether orally or in writing and any service work requested. The validity and interpretation of the contract between the parties shall be governed by the laws of the State of Massachusetts, and the parties agree that jurisdiction and venue over any dispute or proceedings arising out of the contract shall be exclusively in the Courts of the County of Middlesex, State of Massachusetts." },
  { heading: "Force Majeure", body: "This agreement shall NOT include maintenance, repairs, service or replacements necessitated by any loss or damage resulting from any cause beyond the control of American Air LLC, including but not limited to damage or loss due to lack of water, freezing, loss or insufficient electric power or fuel source, hail, flood, windstorms, excessive rain, or snow, freezing weather, lightning, earthquake, theft, fire, riots of any kind, strikes, wars, misuse and negligence by person(s) other than those representing American Air LLC, vandalism, acts of government, building code requirements, insurance requirements, unauthorized adjustments or repair, or any other peril or act of God. The cost of all repairs, modifications or alterations necessitated by the above shall be the responsibility of the Client and payable to American Air LLC at the then current service rate." },
  { heading: "Warranty", body: "American Air LLC warrants that its products and services shall be free from defects in workmanship and materials for thirty (30) days from the date of completion. American Air LLC's sole obligation shall be repair or replace defective parts or its property performing defective service. Except as expressly provided by this Agreement, American Air LLC hereby expressly disclaims and negates any other representation or warranty, express or implied, related to the Services provided under this Agreement (including without limitation any express or implied warranty of merchantability, fitness for a particular purpose of conformity to models or samples or materials). American Air LLC does warrant that all material and labor furnished pursuant to this Agreement shall be free from defects in materials and workmanship. Certain replacement parts or components may be reconditioned or remanufactured in accordance with standard industry practice.\n\nTHIS WARRANTY AND LIABILITY SET FORTH IN THIS AGREEMENT ARE IN LIEU OF ALL OTHER WARRANTIES AND LIABILITIES, WHETHER IN CONTRACT OR IN NEGLIGENCE, EXPRESS OR IMPLIED, IN LAW OR IN FACT, INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE AND/OR OTHERS ARISING FROM COURSE OF DEALING OR TRADE. COMPANY MAKES NO REPRESENTATION OR WARRANTY EXPRESS OR IMPLIED REGARDING PREVENTION BY THE SCOPE OF SERVICES, OR ANY COMPONENT THEREOF OF MOLD, MILDEW, FUNGUS, BACTERIA, MICROBIAL GROWTH, OR ANY OTHER CONTAMINATES. ISS SPECIFICALLY DISCLAIMS ANY LIABILITY IF THE SCOPE OF SERVICES OR ANY COMPONENT THEREOF IS USED TO PREVENT OR INHIBIT THE GROWTH OF SUCH MATERIALS." },
  { heading: "Limitations of Liability", body: "This Agreement does not include responsibility for the design of the system, obsolescence, safety test, removal and reinstallation of valve bodies and dampers, repair or replacement necessitated by freezing weather, electrical power failure, low voltage, burned-out main or branch fuses, low water pressure, vandalism, misuse or abuse of the system(s), negligence of others (including Client), failure of Client to properly operate the system, requirements of governmental, regulatory or insurance agencies, or other causes beyond control of American Air LLC. Service Provider shall not be liable for any delay, loss, damage or detention caused by unavailability of machinery, equipment or materials, delay of carriers, strikes, including those by American Air LLC employees, lockouts, civil or military authority, priority regulations, insurrection or riot, action of the elements, forces of nature, or by any cause beyond its control." },
  { heading: "Additional Services", body: "Where American Air LLC renders service for Client, other than those services specified in the maintenance plan schedule, Client agrees to pay for such services at American Air LLC's then current service rates. Loss of time or productivity due to unexpected events that may restrict or limit access to the equipment, associated equipment or components shall be invoiced at the then current service rates. Labor rates are subject to change without notice except when requested." },
  { heading: "Exclusivity of Service", body: "Client agrees to employ American Air LLC exclusively for the service and repair work of the listed equipment and promptly notify American Air LLC of any condition of the equipment that is unusual or that may adversely affect its operation and reliability. Any alterations, additions, adjustments, or repairs made by others, unless authorized or agreed upon by American Air LLC, will be cause to terminate or renegotiate our obligations under this agreement." },
  { heading: "Transfer of Contract", body: "This Agreement cannot be transferred or assigned without written approval of both parties." },
  { heading: "Indemnity", body: "To the fullest extent permitted by law, each party agrees to indemnify, hold harmless, protect and defend the other, including officers, agents, directors and employees, from any and all liabilities, damages, injury (including bodily injuries and/or death), cost, claims, demands, settlements or suits of any kind, including but not limited to reasonable attorney's fees, arising out of or resulting from (1) indemnifying party's breach of this agreement, and/or (2) the gross negligence and/or willful misconduct by indemnifying party or its employees, contractors, sub-contractors of any tier, directors, officers or agents, or from the presence or exposure to mold, mildew or micro-organisms, and any byproducts of such materials. Client shall have no liability for damages to persons or property caused in whole or in part by any act, omission, or default of ISS, its employees or subcontractors." },
  { heading: "Legal Action", body: "In the event either party must commence legal action is in order enforce or interpret any rights or obligations under this agreement, the prevailing party shall be entitled to recover its reasonable court costs and attorney's fees incurred from the non-prevailing party." },
  { heading: "Insurance", body: "American Air LLC agrees to maintain the following insurance during the term of this agreement with limits not less than shown below and will, upon request from the Client, provide a Certificate of Insurance.\n\nCommercial General Liability: $1,000,000 per occurrence\nAutomobile Liability: $1,000,000 combined single limit\nUmbrella Liability: $3,000,000 per occurrence\nWorker's Compensation: Statutory Limits" },
  { heading: "Hiring of American Air LLC Employees", body: "Client agrees that it will not hire as an employee or contract with as an independent contractor any of the employees of American Air LLC during the term of this Agreement and for a period of twelve (12) months following the termination of the service agreement." },
  { heading: "Hazardous Substances", body: "American Air LLC's obligation under this proposal and any subsequent contract does not include the identification, abatement or removal of asbestos or any other toxic or hazardous substances, hazardous wastes or hazardous materials. In the event such substances, wastes and materials are discovered, American Air LLC's obligation will be to notify the client of their existence. American Air LLC shall have the right thereafter to suspend its work until such substances, wastes or materials and the resultant hazards are removed. The time for completion of work shall be extended to the extent caused by the suspension and the contract price equitably adjusted." },
  { heading: "Subcontract Rights", body: "American Air LLC reserves the right to subcontract certain repairs, if deemed necessary or in the best interest of and following approval by Client. Costs of this work will be handled as a parts sale and standard labor item in accordance with the applicable plan. Supplies, parts or equipment placed on Client's property shall remain the property of American Air LLC until such supplies, parts, or equipment are installed, in it by Client, American Air LLC reserves the right to remove such property within a reasonable period of time, if this agreement is terminated for any reason." },
];

// ⚠️  FLAGGED for Clayton's review — "ISS" appears in Indemnity and Warranty sections.
// This looks like a copy from a previous vendor's template. You may want to replace "ISS" 
// with "American Air LLC" before using this document with customers.

// ── Doc builder ───────────────────────────────────────────────────────────
app.post('/generate', async (req, res) => {
  try {
    const { facility, address, contact, salesName, salesPhone, salesEmail,
            date, price, equipment } = req.body;

    const logoData = fs.readFileSync(path.join(__dirname, 'logo.png'));

    const totalUnits  = equipment.reduce((s, e) => s + e.qty, 0);
    const totalVisits = equipment.reduce((s, e) => s + e.qty * e.visits, 0);

    // ── Build service rows ───────────────────────────────────────────────
    const serviceRows = [];
    SERVICES.forEach((s, i) => {
      serviceRows.push(serviceRow(s[0], s[1]));
      if (i < SERVICES.length - 1) serviceRows.push(spacerRow());
    });

    // ── Equipment schedule rows ──────────────────────────────────────────
    const EQ_COLS = [3400, 900, 1200, 4580];
    function eqSchHdr() {
      return new TableRow({ tableHeader: true, children:
        ["Equipment Type","Qty","Visits / Yr","Model / Serial / Notes"].map((h, i) =>
          cell([para(h, { bold: true, size: 19, color: BLUE })], {
            width: EQ_COLS[i],
            borders: { top: noBorder, bottom: { style: BorderStyle.SINGLE, size: 6, color: BLUE }, left: noBorder, right: noBorder },
            shading:  { fill: LIGHT_BLUE, type: ShadingType.CLEAR },
            margins:  { top: 100, bottom: 100, left: 120, right: 120 },
          })
        )
      });
    }
    function eqSchRow(type, qty, visits, shade) {
      const fill = shade ? ALT_ROW : WHITE;
      const rowB = { top: noBorder, bottom: { style: BorderStyle.SINGLE, size: 2, color: "E0E0E0" }, left: noBorder, right: noBorder };
      return new TableRow({ children:
        [type, String(qty), String(visits), ""].map((v, i) =>
          cell([para(v, { size: 20, color: DARK_GRAY })], {
            width: EQ_COLS[i], borders: rowB,
            shading: { fill, type: ShadingType.CLEAR },
            margins: { top: 90, bottom: 90, left: 120, right: 120 }
          })
        )
      });
    }
    function eqSchTotal() {
      const bTop = { top: { style: BorderStyle.SINGLE, size: 6, color: BLUE }, bottom: noBorder, left: noBorder, right: noBorder };
      return new TableRow({ children: [
        cell([para("Total Units Covered", { bold: true, size: 20, color: BLUE })],
          { width: EQ_COLS[0], borders: bTop, shading: { fill: LIGHT_BLUE, type: ShadingType.CLEAR }, margins: { top: 100, bottom: 100, left: 120, right: 120 } }),
        cell([para(String(totalUnits), { bold: true, size: 20, color: BLUE })],
          { width: EQ_COLS[1], borders: bTop, shading: { fill: LIGHT_BLUE, type: ShadingType.CLEAR }, margins: { top: 100, bottom: 100, left: 120, right: 120 } }),
        cell([para("")], { width: EQ_COLS[2], borders: bTop, shading: { fill: LIGHT_BLUE, type: ShadingType.CLEAR }, margins: { top: 100, bottom: 100, left: 120, right: 120 } }),
        cell([para("")], { width: EQ_COLS[3], borders: bTop, shading: { fill: LIGHT_BLUE, type: ShadingType.CLEAR }, margins: { top: 100, bottom: 100, left: 120, right: 120 } }),
      ]});
    }

    const eqSchRows = [eqSchHdr()];
    equipment.forEach((e, i) => {
      const eq = EQ_CATALOG[e.id];
      if (eq) eqSchRows.push(eqSchRow(eq.name, e.qty, e.visits, i % 2 === 1));
    });
    eqSchRows.push(eqSchTotal());

    // ── Scope blocks ─────────────────────────────────────────────────────
    const scopeBlocks = [];
    equipment.forEach(e => {
      const eq = EQ_CATALOG[e.id];
      if (eq) scopeBlocks.push(...eqScopeBlock(eq.name, e.qty, e.visits, eq.cats));
    });

    // ── T&C paragraphs ───────────────────────────────────────────────────
    const tcChildren = [];
    TC_SECTIONS.forEach(s => {
      tcChildren.push(tcHeading(s.heading));
      s.body.split('\n\n').forEach(block => tcChildren.push(tcBody(block)));
    });

    // ── Header ───────────────────────────────────────────────────────────
    const docHeader = new Header({ children: [
      new Table({
        width: { size: 10080, type: WidthType.DXA },
        columnWidths: [4500, 5580],
        rows: [new TableRow({ children: [
          cell([new Paragraph({ spacing: { before: 0, after: 0 },
            children: [new ImageRun({
              type: "png", data: logoData,
              transformation: { width: 216, height: 50 },
              altText: { title: "American Air Logo", description: "American Air logo", name: "AALogo" }
            })]
          })], { width: 4500, borders: noBorders, vAlign: VerticalAlign.CENTER }),
          cell([
            labelValue("Facility:", facility),
            labelValue("Contact:", contact),
            labelValue("Date:", date),
            labelValue("Prepared by:", `${salesName}  |  ${salesPhone}  |  ${salesEmail}`),
          ], { width: 5580, borders: noBorders, vAlign: VerticalAlign.TOP }),
        ]})]
      }),
      new Paragraph({
        spacing: { before: 100, after: 0 },
        border:  { bottom: { style: BorderStyle.SINGLE, size: 12, color: BLUE } },
        children: []
      })
    ]});

    // ── Document ──────────────────────────────────────────────────────────
    const doc = new Document({
      styles: { default: { document: { run: { font: "Arial", size: 22, color: BLACK } } } },
      sections: [{
        properties: {
          page: {
            size:   { width: 12240, height: 15840 },
            margin: { top: 1080, right: 1080, bottom: 1080, left: 1080 }
          }
        },
        headers: { default: docHeader },
        children: [

          // Hero
          new Table({ width: { size: 10080, type: WidthType.DXA }, columnWidths: [10080],
            rows: [new TableRow({ children: [cell([
              para("Preventative Maintenance Agreement", { bold: true, size: 36, color: BLUE, after: 100 }),
              para("Scheduled, documented service by licensed technicians — designed to protect your equipment investment, maintain tenant comfort, and keep your facilities code-compliant all year long.",
                { size: 21, color: MED_GRAY }),
            ], { width: 10080, borders: noBorders, shading: { fill: LIGHT_BLUE, type: ShadingType.CLEAR }, margins: { top: 200, bottom: 200, left: 240, right: 240 } })]})]
          }),

          new Paragraph({ spacing: { before: 0, after: 160 }, children: [] }),

          // Services
          sectionLabel("Services performed at every scheduled visit"),
          new Paragraph({ spacing: { before: 0, after: 120 }, children: [] }),
          new Table({ width: { size: 10080, type: WidthType.DXA }, columnWidths: [500, 9580], rows: serviceRows }),
          new Paragraph({ spacing: { before: 0, after: 200 }, children: [] }),

          // Benefits
          sectionLabel("Agreement benefits"),
          new Paragraph({ spacing: { before: 0, after: 120 }, children: [] }),
          new Table({ width: { size: 10080, type: WidthType.DXA }, columnWidths: [3360, 3360, 3360], rows: [
            benefitRow(["Priority scheduling", "Discounted repair labor", "Capital Expenditure Planning"]),
            new TableRow({ children: [
              cell([para("", { size: 10 })], { width: 3360, borders: noBorders, shading: { fill: WHITE, type: ShadingType.CLEAR } }),
              cell([para("", { size: 10 })], { width: 3360, borders: noBorders, shading: { fill: WHITE, type: ShadingType.CLEAR } }),
              cell([para("", { size: 10 })], { width: 3360, borders: noBorders, shading: { fill: WHITE, type: ShadingType.CLEAR } }),
            ]}),
            benefitRow(["Extended equipment life", "Manufacturer warranty support", "Dedicated Account Manager"]),
          ]}),
          new Paragraph({ spacing: { before: 0, after: 240 }, children: [] }),

          // Equipment schedule
          sectionLabel("Covered equipment schedule"),
          new Paragraph({ spacing: { before: 0, after: 120 }, children: [] }),
          new Table({ width: { size: 10080, type: WidthType.DXA }, columnWidths: EQ_COLS, rows: eqSchRows }),
          new Paragraph({ spacing: { before: 0, after: 240 }, children: [] }),

          // Summary
          sectionLabel("Agreement summary"),
          new Paragraph({ spacing: { before: 0, after: 140 }, children: [] }),
          new Table({ width: { size: 10080, type: WidthType.DXA }, columnWidths: [3200, 240, 3400, 240, 2760 + 240],
            rows: [new TableRow({ children: [
              cell([
                para("Pricing & Terms", { bold: true, size: 22, color: BLUE, after: 120 }),
                new Table({ width: { size: 2960, type: WidthType.DXA }, columnWidths: [1800, 1160],
                  rows: [
                    ["Agreement term",     "12 months"],
                    ["Total units",        String(totalUnits)],
                    ["Total visits / yr",  String(totalVisits)],
                    ["Annual investment",  price],
                  ].map((r, i, arr) => new TableRow({ children: [
                    cell([para(r[0], { size: 20, color: MED_GRAY })], {
                      width: 1800,
                      borders: { top: noBorder, bottom: i < arr.length-1 ? thinBorder : noBorder, left: noBorder, right: noBorder },
                      margins: { top: 70, bottom: 70, left: 0, right: 0 }
                    }),
                    cell([para(r[1], { size: 20, bold: true, color: r[0] === "Annual investment" ? BLUE : DARK_GRAY })], {
                      width: 1160,
                      borders: { top: noBorder, bottom: i < arr.length-1 ? thinBorder : noBorder, left: noBorder, right: noBorder },
                      margins: { top: 70, bottom: 70, left: 0, right: 0 }
                    }),
                  ]}))
                })
              ], { width: 3200, borders: thinBorders, margins: { top: 160, bottom: 160, left: 160, right: 160 } }),

              cell([para("")], { width: 240, borders: noBorders }),

              cell([
                para("Our Commitment to You", { bold: true, size: 22, color: BLUE, after: 120 }),
                para("Every visit is performed by a trained, licensed HVAC technician familiar with your facility. We document all findings digitally and communicate clearly — no surprises, no upsells you didn't ask for.",
                  { size: 20, color: DARK_GRAY, line: 276 }),
              ], { width: 3400, borders: thinBorders, margins: { top: 160, bottom: 160, left: 200, right: 160 } }),

              cell([para("")], { width: 240, borders: noBorders }),

              cell([
                para("Ready to Get Started?", { bold: true, size: 22, color: WHITE, after: 100 }),
                para("Contact us to confirm your first visit date and finalize this agreement.",
                  { size: 20, color: "CCDDFF", after: 140, line: 276 }),
                para("americanairinc.com",          { size: 20, color: WHITE, bold: true, after: 40 }),
                para("978-640-8880",                { size: 20, color: WHITE, bold: true, after: 40 }),
                para(salesName,                     { size: 20, color: WHITE, after: 20 }),
                para(salesPhone + "  |  " + salesEmail, { size: 18, color: "AABCDD" }),
              ], { width: 3000, borders: noBorders, shading: { fill: BLUE, type: ShadingType.CLEAR }, margins: { top: 160, bottom: 160, left: 200, right: 160 } }),
            ]})]
          }),

          new Paragraph({ spacing: { before: 0, after: 400 }, children: [] }),

          // ── Signature block (matching existing AA agreement format) ──────
          sectionLabel("Agreement execution"),
          new Paragraph({ spacing: { before: 0, after: 160 }, children: [] }),

          // Service provider info block
          new Table({ width: { size: 10080, type: WidthType.DXA }, columnWidths: [4880, 400, 4800],
            rows: [new TableRow({ children: [
              // Client side
              cell([
                para("Client", { bold: true, size: 22, color: BLUE, after: 80 }),
                para(facility, { size: 20, color: DARK_GRAY, after: 40 }),
                ...(address ? [para(address, { size: 19, color: MED_GRAY })] : []),
                ...sigLine("Approved By"),
                ...sigLine("Title"),
                ...sigLine("Printed Name"),
                ...sigLine("Date"),
                ...sigLine("Purchase Order"),
                ...sigLine("Agreement Start Date"),
              ], { width: 4880, borders: thinBorders, margins: { top: 160, bottom: 160, left: 200, right: 160 } }),

              cell([para("")], { width: 400, borders: noBorders }),

              // American Air side
              cell([
                para("American Air LLC", { bold: true, size: 22, color: BLUE, after: 80 }),
                para("80 Brick Kiln Road", { size: 20, color: DARK_GRAY, after: 0 }),
                para("Chelmsford, MA 01824", { size: 20, color: DARK_GRAY, after: 0 }),
                para("Ph: 978-640-8880", { size: 20, color: DARK_GRAY }),
                ...sigLine("Submitted By: " + salesName),
                ...sigLine("Title"),
                ...sigLine("Signature"),
                ...sigLine("Date"),
                ...sigLine("Approved By"),
                ...sigLine("Title"),
                ...sigLine("Printed Name"),
                ...sigLine("Date"),
              ], { width: 4800, borders: thinBorders, margins: { top: 160, bottom: 160, left: 200, right: 160 } }),
            ]})]
          }),

          // ── PAGE 2 — Scope of Work ────────────────────────────────────
          new Paragraph({ children: [new PageBreak()], spacing: { before: 0, after: 0 } }),

          new Table({ width: { size: 10080, type: WidthType.DXA }, columnWidths: [10080],
            rows: [new TableRow({ children: [cell([
              para("Exhibit A \u2014 Scope of Work", { bold: true, size: 32, color: BLUE, after: 80 }),
              para(`Full inspection checklist for all covered equipment at ${facility}. Performed by a licensed technician at every scheduled visit.`,
                { size: 20, color: MED_GRAY }),
            ], { width: 10080, borders: noBorders, shading: { fill: LIGHT_BLUE, type: ShadingType.CLEAR }, margins: { top: 180, bottom: 180, left: 240, right: 240 } })]})]
          }),

          new Paragraph({ spacing: { before: 0, after: 220 }, children: [] }),
          ...scopeBlocks,

          new Paragraph({
            spacing: { before: 120, after: 0 },
            border:  { top: { style: BorderStyle.SINGLE, size: 4, color: "CCCCCC", space: 4 } },
            children: [new TextRun({
              text: "This scope of work applies to all units of each type listed above. Additional findings or repairs outside this scope will be presented in writing for customer approval prior to any work being performed.",
              color: MED_GRAY, size: 18, font: "Arial", italics: true,
            })]
          }),

          // ── PAGE 3 — Terms & Conditions ──────────────────────────────
          new Paragraph({ children: [new PageBreak()], spacing: { before: 0, after: 0 } }),

          new Table({ width: { size: 10080, type: WidthType.DXA }, columnWidths: [10080],
            rows: [new TableRow({ children: [cell([
              para("Planned Maintenance Terms and Conditions", { bold: true, size: 32, color: BLUE, after: 80 }),
              para("American Air LLC \u00B7 80 Brick Kiln Road, Chelmsford MA 01824 \u00B7 978-640-8880", { size: 18, color: MED_GRAY }),
            ], { width: 10080, borders: noBorders, shading: { fill: LIGHT_BLUE, type: ShadingType.CLEAR }, margins: { top: 160, bottom: 160, left: 240, right: 240 } })]})]
          }),

          ...tcChildren,
        ]
      }]
    });

    const buf = await Packer.toBuffer(doc);
    const filename = `${facility.replace(/[^a-z0-9]/gi,'_')}_PMA_${date.replace(/[^a-z0-9]/gi,'_')}.docx`;
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
    res.send(buf);

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`\n  American Air Proposal Tool\n  Open: http://localhost:${PORT}\n`));
